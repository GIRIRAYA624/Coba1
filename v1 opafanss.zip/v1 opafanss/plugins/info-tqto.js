let handler = async (m) => {

let anu =` Thanks To
- ᴀᴅɪᴡᴀᴊsʜɪɴɢ
- sʜɪʀᴏᴋᴀᴍɪʀʏᴢɴ
- ʙᴏᴄʜɪʟɢᴀᴍɴɢ
- xᴄᴛ𝟶𝟶𝟽
- ᴇᴋᴜᴢɪᴋᴀ
- ɴᴜʀᴜᴛᴏᴍᴏ
- ɪᴍʏᴀɴxɪᴀᴏ
- ᴠʏɴᴀᴀᴄʜᴀɴ
- xᴛʀᴀᴍ-ᴛᴇᴀᴍ
- ʀᴇʏᴢ ʜᴀʏᴀɴᴀsɪ
- ʀᴇxxᴢʏɴ
- ʀᴀᴘɪᴋᴢ
- ᴠʏᴢᴛᴇʀ ɪᴍᴘᴀᴄᴛ
- ᴀʀɪʟ
- ᴅɪᴍs ssᴀ
- ssᴀ ᴛᴇᴀᴍ
- ɴᴀᴊᴍʏᴡ
- ᴘʀɪɴᴢ
- ʀʏᴢᴇɴ
- ᴀᴍɪʀᴜʟ
- ᴋʏᴜᴜʀᴢʏ
- ᴋʏᴢʀʏᴢᴢ
- ʜʏᴜᴜ
- ʀɪᴏᴏ
- sᴋɪᴢᴏ
- sɪᴘᴜᴛᴢx
- xʏʀᴏ
- ʀᴇʀᴇᴢ
- ᴛɪᴏ
- ᴠᴀʀᴏ
`
await m.reply(anu)
}
handler.help = ['tqto', 'credit']
handler.tags = ['info']
handler.command = /^(tqto|credit)$/i

export default handler