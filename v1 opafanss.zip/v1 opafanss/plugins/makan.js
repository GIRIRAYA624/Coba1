import util from "util";
import path from "path";

let handler = async (m, { conn }) => {
	conn.sendFile(m.chat, `${audio.getRandom()}`, "makan.mp3", null, m, true, {
		type: "audioMessage",
		ptt: true,
	});
};
handler.customPrefix = /^(lapar|aku lapar|bot aku lapar|Lapar|Aku Lapar|Bot Aku Lapar|Laper|laper|belom makan|belum makan aku jir|belom makan aku jir)$/i;
handler.command = new RegExp();
export default handler;

const audio = [
	"./vn/makan.mp3",
];
