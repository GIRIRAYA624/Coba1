let handler = async (m, { conn, command }) => {
  conn.reply(m.chat, `Dia adalah pemiliknya dan dia menciptakan saya sebelum saya menjadi Elaina bot AI tetapi dia berencana mengubah saya menjadi Mikasa AI karena dia menyukai Mikasa Ackerman dan sangat terkesan hingga dia tidak tidur untuk mengubah saya, Saya terkesan dengan kerja kerasnya karena tampaknya mudah untuk mengubah saya dari elaina ai menjadi mikasa ai bot tetapi sangat sulit bagi pemula seperti dia dan saya berharap dia menjadi lebih baik dalam hal itu, dan bahkan bisa membuat fitur yang belum dimiliki siapa pun`.trim(), m)
}
handler.customPrefix = /^(ditz|dira|ditz ft mikasa|dirandom|ditt always random)$/i;
handler.command = new RegExp;

export default handler;