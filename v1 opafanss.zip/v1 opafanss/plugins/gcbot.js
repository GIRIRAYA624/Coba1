import fs from 'fs';
import fetch from 'node-fetch';
let handler = async (m, { conn }) => { 

         let caption = `*Mʏ Gᴄ Oғғɪᴄɪᴀʟ*`;
  conn.reply(m.chat, caption, m, {
      contextInfo: {
        externalAdReply: {
          title: "ᴏᴘᴀꜰᴀɴꜱꜱ  M U L T I D E V I C E",
          thumbnailUrl: 'https://telegra.ph/file/19e41947c0a6ae28dbf62.jpg',
          sourceUrl: sgc,
          mediaType: 1,
          renderLargerThumbnail: true, 
          showAdAttribution: true
        }
      }
    });
 }
 handler.help = ['gcbot', 'gcopafanss'];
handler.tags = ['main'];
handler.command = /^(gcbot|groupbot|botgc|botgroup|gcopafanss|groupopafanss)$/i;
export default handler;