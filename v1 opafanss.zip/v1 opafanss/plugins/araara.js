import util from "util";
import path from "path";

let handler = async (m, { conn }) => {
	conn.sendFile(m.chat, `${audio.getRandom()}`, "araara.mp3", null, m, true, {
		type: "audioMessage",
		ptt: true,
	});
};
handler.customPrefix = /^(ara ara|bot ara ara dong|ara|Ara|Bot ara ara dong|Bot Ara Ara dong|Bot Ara Ara Dong|BOT ARA ARA DONG|ARA|ARA ARA|Ara Ara|Give me ara ara|give me ara ara|pls ara)$/i;
handler.command = new RegExp();
export default handler;
const audio = [
	"./vn/araara.mp3",
];