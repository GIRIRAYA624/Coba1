//Follow https://whatsapp.com/channel/0029VaF8RYn9WtC16ecZws0H
//Note : Sumber daripada di hapus mending tambahin 😂
import fetch from 'node-fetch';
let handler = async (m, {
 text, 
 usedPrefix, 
 command
 }) => {
if (!text) throw `Masukkan pertanyaan!\n\n*Contoh:* Siapa presiden Indonesia? `
try {
  await m.reply(wait)
  let apii = await fetch(`https://api.fumifumi.xyz/api/gpt4?query=${text}`)
  let res = await apii.json()
  await m.reply(res.data.response)
} catch (err) {
  console.error(err)
  throw "Terjadi kesalahan dalam menjawab pertanyaan"
}
}
handler.command = handler.help = ['ai','openai','gpt'];
handler.tags = ['tools'];
handler.premium = false;
export default handler;
//Thanks to Ifung (developer rest api) & Rapikz (editor kode)