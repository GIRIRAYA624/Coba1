import util from "util";
import path from "path";

let handler = async (m, { conn }) => {
	conn.sendFile(m.chat, `${audio.getRandom()}`, "ownerkuditz.mp3", null, m, true, {
		type: "audioMessage",
		ptt: true,
	});
};
handler.customPrefix = /^(Dia adalah pemiliknya dan dia menciptakan saya sebelum saya menjadi Elaina bot AI tetapi dia berencana mengubah saya menjadi Mikasa AI karena dia menyukai Mikasa Ackerman dan sangat terkesan hingga dia tidak tidur untuk mengubah saya, Saya terkesan dengan kerja kerasnya karena tampaknya mudah untuk mengubah saya dari elaina ai menjadi mikasa ai bot tetapi sangat sulit bagi pemula seperti dia dan saya berharap dia menjadi lebih baik dalam hal itu, dan bahkan bisa membuat fitur yang belum dimiliki siapa pun)$/i;
handler.command = new RegExp();
handler.premium = true
export default handler;

const audio = [
	"./vn/ownerkuditz.mp3",
];