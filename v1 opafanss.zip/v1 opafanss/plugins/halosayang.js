import util from "util";
import path from "path";

let handler = async (m, { conn }) => {
	conn.sendFile(m.chat, `${audio.getRandom()}`, "halosayang.mp3", null, m, true, {
		type: "audioMessage",
		ptt: true,
	});
};
handler.customPrefix = /^(halo bot|halo|selamat pagi|hai|hi|haloo|pagi bot|bot|Selamat pagi|Pagi|Halo|Halo Sayang|halo sayang)$/i;
handler.command = new RegExp();
export default handler;
const audio = [
	"./vn/halosayang.mp3",
];