let handler = async (m { conn, text })
  if (args[0]) return kiibut(`*FORMAT SALAH ⚠️*
  
  _Example: .cpanel username_`);
  if(command = '1gb') {
    ram = '1050'
    disk = '1050'
    cpu = '35'
    amount = '1000'
  } else if(command = '2gb') {
    ram = '2100'
    disk = '2100'
    cpu = '70'
    amount = '2000'
  }
  
  try {
  const pay = await (await fetch(`https://api.elxyz.me/orkut/createpayment?apikey=${elxyz}&amount=${amount}&codeqr=${codeqr}`)).json();
  const tek = `*BERIKHT DETAIL PEMBAYARAN*
  
  *TRANSACTION ID:* ${pay.result.qrData.transactionId}
  *TRANSACTION AMOUNT: ${pay.result.qrData.amount}
  *TRANSACTION EXPIRED: ${pay.result.qrData.expirationTime}
  
  *Silahkan scan QRIS di atas untuk pembayaran.*`
  await kiicode.sendMessage(m.chat, { image: { url: `${pay.result.qrData.qrImageUrl}`}, caption: `${tek}`}, m)
  const apiUrl = `https://api.elxyz.me/orkut/checkpayment?apikey=${elxyz}&merchant=${orkutmerchant}&token=${orkutapi}`;
  let isTransactionComplete = false;
  while (!isTransactionComplete) {
    try {
      const response = await axios.get(apiUrl);
      const result = response.data;
      console.log('Data transaksi:', result);
      if (result && result.amount && parseInt(result.amount) === parseInt(amount)) {
        isTransactionComplete = true;
  
  let u = m.sender
  let email = args[0] + "@gmail.com"
  let username = args[0]
  akunlo = `${thumb}` 
if (!u) return
let d = (await kiicode.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username + "001"
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
m.reply(`> *INFORMATION SUCCES*\n> *sᴜᴄᴄᴇs ʙᴜʏ ᴘᴀɴᴇʟ ᴅᴇɴɢᴀɴ ᴜsᴇʀ ɪᴅ: ${user.id}*`)
ctf = `Hai @${u.split`@`[0]}

⎙─➤ *👤USERNAME* : ${user.username}
⎙─➤ *🔐PASSWORD* : ${password}
⎙─➤ *🌐LOGIN* : ${domain}

NOTE:
OWNER HANYA MENGIRIM 1X DATA 
AKUN ANDA MOHON DI SIMPAN BAIK BAIK
KALAU DATA AKUN ANDA HILANG OWNER
TIDAK DAPAT MENGIRIM AKUN ANDA LAGI
=====================================
`
kiicode.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: m })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"description": " ",
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return m.reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
let p = await m.reply(`
*SUCCESSFULLY ADD USER + SERVER*
TYPE: user
ID: ${user.id}
NAME: ${user.first_name} ${user.last_name}
MEMORY: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
CPU: ${server.limits.cpu}%

`)
      }
    } catch (error) {
    kiibut(`Error memeriksa status transaksi:`)
  }
  if (!isTransactionComplete) {
    await new Promise(resolve => setTimeout(resolve, 10000));
  }
  }

} catch (error) {
  kiibut(`Error membuat QRIS atau memeriksa status`)
}

handler.help = ["cpanel"];
handler.command = ["cpanel"];
handler.tags = ["create-panel"]

export default handler