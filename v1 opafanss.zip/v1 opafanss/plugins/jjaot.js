import { mediafiredl } from "@bochilteam/scraper";
let handler = async (m, { conn }) => {
conn.sendMessage(m.chat, { react: { text: '🕒', key: m.key }})
	let lol = [
		"https://www.mediafire.com/file/lbj7u3o8raerg70/ssstik.io_%2540tsusakii_1721994094007.mp4/file"
	"https://www.mediafire.com/file/6w94dbaeiy9dgr8/ssstik.io_%2540shingeki.fly_1721995998179.mp4/file"
	"https://www.mediafire.com/file/o791soi3prnmxhn/ssstik.io_%2540rinayashe1_1721972043475.mp4/file"
	"https://www.mediafire.com/file/gmalr0y689643wv/ssstik.io_%2540qwinleonhardt_1721996096470.mp4/file"
	"https://www.mediafire.com/file/iwiyoene64xyq5p/ssstik.io_%2540dyrgaaa_1721996039406.mp4/file"
	"https://www.mediafire.com/file/iwiyoene64xyq5p/ssstik.io_%2540dyrgaaa_1721996039406.mp4/file"
	"https://www.mediafire.com/file/5v0kljaefuwcav3/ssstik.io_%2540deverall__1721996216595.mp4/file",
	];
	let anu = lol[Math.floor(Math.random() * lol.length)];
	
	let lol2 = [
`${anu}`, 
'https://www.mediafire.com/file/lbj7u3o8raerg70/ssstik.io_%2540tsusakii_1721994094007.mp4/file"
	"https://www.mediafire.com/file/6w94dbaeiy9dgr8/ssstik.io_%2540shingeki.fly_1721995998179.mp4/file"
	"https://www.mediafire.com/file/o791soi3prnmxhn/ssstik.io_%2540rinayashe1_1721972043475.mp4/file"
	"https://www.mediafire.com/file/gmalr0y689643wv/ssstik.io_%2540qwinleonhardt_1721996096470.mp4/file"
	"https://www.mediafire.com/file/iwiyoene64xyq5p/ssstik.io_%2540dyrgaaa_1721996039406.mp4/file"
	"https://www.mediafire.com/file/iwiyoene64xyq5p/ssstik.io_%2540dyrgaaa_1721996039406.mp4/file"
	"https://www.mediafire.com/file/5v0kljaefuwcav3/ssstik.io_%2540deverall__1721996216595.mp4/file', 
]

let anu2 = lol2[Math.floor(Math.random() * lol2.length)];
	
	let res = await mediafiredl(anu2);
	let { url, url2, filename, ext, aploud, filesize, filesizeH } = res;
	await conn.sendFile(m.chat, url, filename, '```Success...\nDont forget to donate```', m, {
		asDocument: false,
	});
};
handler.command = /^(jjaot)$/i
handler.help = ["jjaot","jedagjeduaot"];
handler.tags = ["anime","internet"];
handler.command = ["jjaot","jedagjedugaot"];
handler.limit = true
export default handler 